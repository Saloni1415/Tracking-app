import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';

import { MouseEvent } from '@agm/core';
import { Observable } from 'rxjs/Observable';

import 'rxjs/add/observable/interval';
import 'rxjs/add/operator/takeWhile';

@Component({
  selector: 'app-ordertrack',
  templateUrl: './ordertrack.component.html',
  styleUrls: ['./ordertrack.component.scss']
})
export class OrdertrackComponent implements OnInit {

  constructor() { }

  iconloc:string=
    'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSzzBFBm89uos6KJk-2kXKfKYlHT_jcq6x4_eaw_44PHVeDoDYd&usqp=CAU'
    // scaledSize: {
    //     width: 40,
    //     height: 60
    // }


    
  iconh:number=20;
    // google maps zoom level
    zoom: number = 16;

    // initial center position for the map
  
    currentPos: point = {
      lat: 50.082730,
      lng: 14.431697
    };
    points: point[] = [];
    // driversList: point[] = [];
    drivers={    lat:50.083200,
          lng: 14.430987};
    tmpPoints: point[] = [{
          lat: 50.082911,
          lng: 14.431411
        },{
          lat: 50.083644,
          lng: 14.430367
        }];


       

  ngOnInit(): void {
    let i = 0;
    const obs = Observable.interval(500)
      .takeWhile((v) =>  i < this.tmpPoints.length)
      .subscribe(() => {
        const pos = this.tmpPoints[i];
        this.points.push(pos);
        // this.driversList.push(pos);
        this.currentPos = pos;
        i++;
      })
  }

  
    
  

  mapClicked(){}

}


interface point {
  lat: number;
  lng: number;
}
